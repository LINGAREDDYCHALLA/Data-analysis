df['price'] = df['price'].replace('Free', '0')            
# df['price'] = df['price'].replace('[\$,]', '', regex=True)  
# df['price'] = df['price'].astype(float)                  
# df=df.drop_duplicates()
# print(df)
# print(df.duplicated().sum())
# price_engagement = df.groupby('price')[['num_subscribers', 'num_reviews']].mean().reset_index()





# #1.
# plt.figure(figsize=(8, 6))
# sns.lineplot(data=price_engagement, x='price', y='num_subscribers', label='Average Subscribers')
# sns.lineplot(data=price_engagement, x='price', y='num_reviews', label='Average Reviews')
# plt.title('Average Engagement by Course Price')
# plt.xlabel('Price')
# plt.ylabel('Average Count')
# plt.legend()
# plt.grid(True)
# plt.show()


# #2
# df_cleaned = df[['price', 'num_subscribers', 'num_reviews', 'num_lectures', 'content_duration']]
# corr = df_cleaned.corr()
# plt.figure(figsize=(6,6))
# sns.heatmap(corr, annot=True, cmap='coolwarm', fmt=".2f", linewidths=0.5)
# plt.title('Correlation Heatmap of Udemy Course Features')
# # plt.show()


# #3
# top_courses = df.sort_values(by='num_subscribers', ascending=False).head(10)
# plt.figure(figsize=(10,6))
# sns.barplot(x='num_subscribers', y='course_title', data=top_courses, palette='coolwarm')
# plt.title('Top 10 Courses by Subscribers')
# plt.xlabel('Subscribers')
# plt.ylabel('Course Title')
# plt.show()

# #4
# price_vs_subs = df.groupby('price')['num_subscribers'].mean().reset_index()
# price_vs_subs = price_vs_subs.sort_values(by='price')
# plt.figure(figsize=(10, 6))
# plt.plot(price_vs_subs['price'], price_vs_subs['num_subscribers'], marker='o', color='teal')
# plt.title('Average Subscribers by Course Price')
# plt.xlabel('Price (USD)')
# plt.ylabel('Average Number of Subscribers')
# plt.grid(True)
# plt.show()

# #5
# plt.figure(figsize=(12, 6))
# sns.boxplot(data=df, x='subject', y='num_reviews', palette='Set2')
# plt.title('Number of Reviews by Subject')
# plt.xlabel('Subject')
# plt.ylabel('Number of Reviews')
# plt.xticks(rotation=45)
# plt.grid(True)
# plt.show()
